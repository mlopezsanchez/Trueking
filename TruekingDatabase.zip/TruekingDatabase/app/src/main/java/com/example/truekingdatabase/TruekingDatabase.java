package com.example.truekingdatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TruekingDatabase {
    TruekingDatabase tdb = new TruekingDatabase();
    public Connection Conexion() {
        String url = "jdbc:mysql://localhost:3306/TruekingDatabase";
        String usuario = "alumno";
        String contrasenia = "alumno";
        try {
            Connection conexion = DriverManager.getConnection(url, usuario, contrasenia);
            return conexion;
        } catch (SQLException e) {
            System.err.println("No existe la base de datos");
        }
        return null;
    }
    public String crearTablas(Connection conexion) {
        try {
            Statement st = conexion.createStatement();
            ResultSet Usuario = st.executeQuery("CREATE TABLE Usuario (\n" +
                    "    idUsuario INT NOT NULL,\n" +
                    "    nombre VARCHAR(100) NOT NULL,\n" +
                    "    correo VARCHAR(100) UNIQUE NOT NULL, -- Asumiendo que el correo debe ser único\n" +
                    "    PRIMARY KEY (idUsuario)\n" +
                    ");");
            ResultSet Publicacion = st.executeQuery("CREATE TABLE Publicacion (\n" +
                    "    idPublicacion INT NOT NULL,\n" +
                    "    titulo VARCHAR(255) NOT NULL,\n" +
                    "    idUsuario INT NOT NULL, -- Clave foránea para la relación \"Crea\" con Usuario (1:N)\n" +
                    "    PRIMARY KEY (idPublicacion),\n" +
                    "    FOREIGN KEY (idUsuario) REFERENCES Usuario(idUsuario)\n" +
                    ");");
            ResultSet Mensaje = st.executeQuery("CREATE TABLE Mensaje (\n" +
                    "    idMensaje INT NOT NULL,\n" +
                    "    texto TEXT,\n" +
                    "    idUsuarioEmisor INT NOT NULL, -- Clave foránea para la relación \"Envía\" con Usuario (1:N)\n" +
                    "    idPublicacion INT NOT NULL,    -- Clave foránea para la relación con Publicacion (N:N, implementada a través de Mensaje)\n" +
                    "    PRIMARY KEY (idMensaje),\n" +
                    "    FOREIGN KEY (idUsuarioEmisor) REFERENCES Usuario(idUsuario),\n" +
                    "    FOREIGN KEY (idPublicacion) REFERENCES Publicacion(idPublicacion)\n" +
                    ");");

        } catch (SQLException e) {
            System.err.println("No existe la base de datos");
        }
        return "No se pudo crear la tabla o ya existe";
    }

    public void insertarUsuarios(Connection conexion, Scanner sc) {
        System.out.println("Inserte el nombre");
        String nombreUsuario = sc.next();
        System.out.println("Escriba su correo");
        String correoUsuario = sc.next();
        System.out.println("Introduciendo usuario");
        try {
            Statement st = conexion.createStatement();
            ResultSet rs = st.executeQuery("INSERT INTO alumnos (nombre, correo) VALUES " + "('" + nombreUsuario + "', '" + correoUsuario + "')");
        } catch (SQLException e) {
            System.err.println("No se pudo acceder a la base de datos");
        }

    }

    public void eliminarPerfil(Connection conexion, int idUsuario) {
        try {
            Statement st = conexion.createStatement();
            ResultSet rs = st.executeQuery("DELETE FROM alumnos WHERE id = " + idUsuario);
            System.out.println("Usuario eliminado correctamente");
        } catch (SQLException e) {
            System.err.println("No se encontró al usuario con id: " + idUsuario);
        }
    }

    public void editarPerfil(Connection conexion, Scanner sc, int idUsuario) {
        try {
            Statement st = conexion.createStatement();
            System.out.println("Elija que desea cambiar");
            System.out.println("1. Nombre");
            System.out.println("2. Correo");
            int eleccion = sc.nextInt();
            if (eleccion == 1) {
                System.out.println("Introduzca el nuevo nombre");
                String nombreNuevo = sc.next();
                ResultSet rs = st.executeQuery("UPDATE alumnos SET nombre = " + nombreNuevo +
                " WHERE id = " + idUsuario);
                System.out.println("Nombre cambiado con exito");
            }
            if (eleccion == 2) {
                System.out.println("Introduzca el nuevo correo");
                String correoNuevo = sc.next();
                ResultSet rs = st.executeQuery("UPDATE alumnos SET correo = " + correoNuevo +
                        " WHERE id = " + idUsuario);
                System.out.println("Correo cambiado con exito");
            } else {
                System.out.println("Eso no es una opción");
            }
            ResultSet rs = st.executeQuery("");
        } catch (SQLException e) {
            System.err.println("No se encontro al usuario");
        }

    }
}
