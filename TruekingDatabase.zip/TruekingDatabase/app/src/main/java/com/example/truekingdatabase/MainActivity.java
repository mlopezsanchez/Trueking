package com.example.truekingdatabase;

import java.sql.Connection;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MainActivity {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        TruekingDatabase tdb = new TruekingDatabase();
        Connection connection = tdb.Conexion();
        tdb.crearTablas(connection);
        System.out.println("Bienvenido a la base de datos de Trueking");
        System.out.println("¿Qué desea hacer?" +
                "1. Crear tablas" +
                "2. Insertar usuarios" +
                "3. Eliminar pérfil" +
                "4. Editar pérfil" +
                "5. Salir de la base de datos");
        try {
            int opcion = teclado.nextInt();
            while (opcion < 0 || opcion > 5) {
                System.out.println("Esa opción no es válida, vuelva a elegir.");
                opcion = teclado.nextInt();
            }
            while (opcion != 4) {
                switch (opcion) {
                    case 1:
                        System.out.println("CREANDO TABLAS...");
                        System.out.println("¿Desea hacer algo mas?" +
                                "1. Crear tablas" +
                                "2. Insertar usuarios" +
                                "3. Eliminar pérfil" +
                                "4. Editar pérfil" +
                                "5. Salir de la base de datos");
                        tdb.crearTablas(connection);
                        opcion = teclado.nextInt();
                        break;

                    case 2:

                        tdb.insertarUsuarios(connection, teclado);
                        System.out.println("¿Desea hacer algo mas?" +
                                "1. Crear tablas" +
                                "2. Insertar usuarios" +
                                "3. Eliminar pérfil" +
                                "4. Editar pérfil" +
                                "5. Salir de la base de datos");
                        opcion = teclado.nextInt();
                        break;

                    case 3:
                        System.out.println("Inserte el id del usuario a borrar");
                        int idUsuarioABorrar = teclado.nextInt();
                        tdb.eliminarPerfil(connection, idUsuarioABorrar);
                        System.out.println("¿Desea hacer algo mas?" +
                                "1. Crear tablas" +
                                "2. Insertar usuarios" +
                                "3. Eliminar pérfil" +
                                "4. Editar pérfil" +
                                "5. Salir de la base de datos");
                        opcion = teclado.nextInt();
                        break;

                    case 4:
                        System.out.println("Introduzca el id del usuario a editar");
                        int idUsuarioAEditar = teclado.nextInt();
                        tdb.editarPerfil(connection, teclado, idUsuarioAEditar);
                        System.out.println("¿Desea hacer algo mas?" +
                                "1. Crear tablas" +
                                "2. Insertar usuarios" +
                                "3. Eliminar pérfil" +
                                "4. Editar pérfil" +
                                "5. Salir de la base de datos");
                        opcion = teclado.nextInt();
                        break;
                    default:
                        System.out.println("Eso no es una opción pruebe de nuevo");
                        opcion = teclado.nextInt();
                        break;
                }
            }
        } catch (InputMismatchException e) {
            System.err.println("El tipo de valor que ha introducido no coincide con el que se le ha pedido.");
            System.err.println("Porfavor, intentelo de nuevo.");
        }
        System.out.println("Cerrando la base de datos");
    }
}
